public class Main {
    public static void main(String[] args) {
        // Obtendo a única instância do GameSettings
        GameSettings settings1 = GameSettings.getInstance();

        // Modificando algumas configurações
        settings1.setVolume(75);
        settings1.setResolucao("1280x720");
        settings1.setDificuldade("Difícil");

        // Exibindo configurações
        System.out.println("Configurações Atuais:");
        System.out.println(settings1.getConfiguracoes());

        // Obtendo a instância em outro local do código
        GameSettings settings2 = GameSettings.getInstance();

        // Mostrando que as alterações permanecem
        System.out.println("\nConfigurações Acessadas em Outro Local:");
        System.out.println(settings2.getConfiguracoes());

        // Verificando que ambas são a mesma instância
        System.out.println("\nAs instâncias são as mesmas? " + (settings1 == settings2));
    }
}
