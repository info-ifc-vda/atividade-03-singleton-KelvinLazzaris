import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class GameSettings {
    private static GameSettings instance;
    private JsonObject settings;
    private static final Gson gson = new Gson();

    // Construtor privado para impedir novas instâncias de maneira direta
    private GameSettings() {
        settings = new JsonObject();
        settings.addProperty("volume", 50);
        settings.addProperty("resolucao", "1920x1080");
        settings.addProperty("dificuldade", "Médio");
    }

    // Método para acessar a única instância
    public static GameSettings getInstance() {
        if (instance == null) {
            instance = new GameSettings();
        }
        return instance;
    }

    // Métodos para modificar configurações
    public void setVolume(int volume) {
        if (volume >= 0 && volume <= 100) {
            settings.addProperty("volume", volume);
        } else {
            System.out.println("Volume deve estar entre 0 e 100.");
        }
    }

    public void setResolucao(String resolucao) {
        settings.addProperty("resolucao", resolucao);
    }

    public void setDificuldade(String dificuldade) {
        if (dificuldade.equals("Fácil") || dificuldade.equals("Médio") || dificuldade.equals("Difícil")) {
            settings.addProperty("dificuldade", dificuldade);
        } else {
            System.out.println("Dificuldade inválida. Escolha entre 'Fácil', 'Médio' ou 'Difícil'.");
        }
    }

    // Métodos para recuperar configurações
    public int getVolume() {
        return settings.get("volume").getAsInt();
    }

    public String getResolucao() {
        return settings.get("resolucao").getAsString();
    }

    public String getDificuldade() {
        return settings.get("dificuldade").getAsString();
    }

    // Método para exibir todas as configurações como JSON
    public String getConfiguracoes() {
        return gson.toJson(settings);
    }
}
